Advanced Database Organization: Fall 2016

Assignment#1 - Storage Manager

Storage manager controls the placement of data on disk and its movement between disk and main memory. The storage manager keeps track of the location of files on the disk and obtains the block or blocks containing a file on request from the buffer manager.

This assignment involves different functionalities such as creating, reading, writing, and destroying files.

Team members:

Divya Vasireddy - A20370052
JayaVijay Jayavelu - A20379656
Naveen Sampath - A20373010
Pavithra Vinay - A20369869 

