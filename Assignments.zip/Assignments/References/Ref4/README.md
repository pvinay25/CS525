# iit_cs525_spring_2015
WARNING: You can view this code as reference, but DO NOT plagiarize by copying any code from this repository. You will get caught. And I really don't think you can understand my code easily.

This is the repository of IIT CS 525 Advanced Database Organization in Spring 2015. This project is to accomplish assignments of this course. All rights reserved.

Created by:
	Xin Su <xsu11@hawk.iit.edu>

Cooperated with:
	Chengnan Zhao <czhao18@hawk.iit.edu>,
	Jie Zhou <jzhou49@hawk.iit.edu>,
	Xiaolang Wang <xwang122@hawk.iit.edu>

Assignment 1 Schedule:
	02/10/2015 - DEV Phase complete: Code and Unit Test
	02/15/2015 - SIT Phase complete: System Integration Test
	02/17/2015 - Delivery: Code and Documentation

Assignment 2 Schedule:
	03/16/2015 - DEV Phase complete: Code and Unit Test
	03/22/2015 - SIT Phase complete: System Integration Test
	03/24/2015 - Delivery: Code and Documentation

Assignment 3 Schedule:
	04/08/2015 - DEV Phase complete: Code and Unit Test
	04/18/2015 - SIT Phase complete: System Integration Test
	04/20/2015 - Delivery: Code and Documentation

Assignment 4 Schedule (unfinished):
	04/26/2015 - DEV Phase complete: Code and Unit Test
	04/30/2015 - SIT Phase complete: System Integration Test
	05/05/2015 - Delivery: Code and Documentation
