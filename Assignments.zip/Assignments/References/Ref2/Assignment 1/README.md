# Assignment 1

Details about this assignment can be found here <http://cs.iit.edu/~cs525/assign1.html>
