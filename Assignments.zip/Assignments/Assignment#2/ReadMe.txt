Advanced Database Organization: Fall 2016

Assignment#2 - Buffer Manager


Team members:


Divya Vasireddy - A20370052

JayaVijay Jayavelu - A20379656

Naveen Sampath - A20373010

Pavithra Vinay - A20369869 



About this Assignment:

Buffer Manager reads disk pages into main memory page. The collection of main memory pages (called frames) used by the Buffer Manager for this purpose is called Buffer Pool.
With the Buffer Manager program can make changes inside the memory, and write file once when work is finished. in our code we are handling Buffer pool to manage several buffer pages.
Each Buffer pool keeps list of page handles. Before buffer manager pins any page, program will check whether pool is full or not. If pool is full we are using two page 
replacement strategies like LRU and FIFO for replacing the less priority page.

We are using two stucts to manage buffer page. First struct stores the Total Write and Read I/O counts and priority count for buffer pool.
Second struct stores page information like Active/Inactive,read count,write count,Dirty page or not and page priority.
We are checking memory leak condition in our code.

We have added 2 new error codes in dberror.h:
RC_INVALID_BM - To check if the input has invalid number of pages in input.
RC_CLOSE_FILE_FAILED - To check if the page file can be closed without any problem.

This assignment has five .c files and six header files, a Makefile and README:

1. buffer_mgr_stat.c
2. buffer_mgr_stat.h
3. buffer_mgr.c
4. buffer_mgr.h
5. dberror.c
6. dberror.h
7. dt.h
8. storage_mgr.c
9. storage_mgr.h
10. test_assign2_1.c
11. test_helper.h
12. Makefile
13. README

To run the code:

1.Go to terminal
2.Change the directory to where Makefile is present.
3.Type “make” (or “make all”) command, code will be compiled and an output file will be created.
4.Type “./output” to see the output.
5.Type make clean if you want to clear the output files.






