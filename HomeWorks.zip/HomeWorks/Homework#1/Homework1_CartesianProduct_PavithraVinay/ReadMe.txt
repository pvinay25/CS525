Title - Cartesian Product
Author - Pavithra Vinay
CWID - A20369869

About this program:
Programming Language Used - Java
There are 2 classes ‘Cartesian Product’ and ‘CP_Client’.
I am reading data from 2 different files and generating the cartesian product.
‘Cartesian Product’ has all the methods to generate the result.
‘CP_Client’ has the main method.

I have included below data in file1 and file2 respectively:

/*File1
[id, firstName, lastName, department] - column headers for reference.*/
1,John,Doe,CS
2,Erin,Scott,DataScience
3,Sue,Miller,EC
4,Sara,Miller,ITM

/*File2
[courseName,courseId] - column headers for reference */
ADO,CS525
DBO,CS425
DAA,CS535
CN,EC501
SPM,CS587

Expected output (not necessarily in the same order):
/*[id, firstName, lastName, department, courseName, courseId] column headers for reference */
4	Sara	Miller	ITM	SPM	CS587	
4	Sara	Miller	ITM	CN	EC501	
4	Sara	Miller	ITM	DAA	CS535	
4	Sara	Miller	ITM	DBO	CS425	
4	Sara	Miller	ITM	ADO	CS525	
3	Sue	Miller	EC	SPM	CS587	
3	Sue	Miller	EC	CN	EC501	
3	Sue	Miller	EC	DAA	CS535	
3	Sue	Miller	EC	DBO	CS425	
3	Sue	Miller	EC	ADO	CS525	
2	Erin	Scott	DataScience	SPM	CS587	
2	Erin	Scott	DataScience	CN	EC501	
2	Erin	Scott	DataScience	DAA	CS535	
2	Erin	Scott	DataScience	DBO	CS425	
2	Erin	Scott	DataScience	ADO	CS525	
1	John	Doe	CS	SPM	CS587	
1	John	Doe	CS	CN	EC501	
1	John	Doe	CS	DAA	CS535	
1	John	Doe	CS	DBO	CS425	
1	John	Doe	CS	ADO	CS525

Note: You can modify the content of the files and test the output. Code has been included to test the amount of time it takes to generate the result (code block is commented, please make sure to uncomment to see the time in ms).

To run this program:
Open source code in an IDE of your choice and execute CP_Client class. Make sure to keep the test files in the same directory.


