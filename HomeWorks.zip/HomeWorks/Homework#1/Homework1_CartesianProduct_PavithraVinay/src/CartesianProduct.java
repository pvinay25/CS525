import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

public class CartesianProduct {

	public CartesianProduct() {

	}

	public ArrayList<String[]> getIndividualItems(HashMap<String, String> map) {
		ArrayList<String[]> list = new ArrayList<String[]>();
		for (Entry<String, String> entry : map.entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue();
			String tokens[] = value.split(",");
			list.add(tokens);
		}
		return list;
	}

	public HashMap<String, String> readDataFromFile(String fileName) {
		HashMap<String, String> map1 = null;
		try {
			Scanner file1 = new Scanner(new File(fileName));
			map1 = new HashMap<String, String>();

			int count = 1;
			while (file1.hasNextLine()) {

				map1.put("line" + count, file1.nextLine());
				count++;

			}

			file1.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return map1;
	}

	public void showCartesianProduct(ArrayList<String[]> list1, ArrayList<String[]> list2, String[] test) {

		for (String[] l1 : list1) {
			for (int i = 0; i < l1.length; i++) {
				test[i] = l1[i];
			}

			for (String[] l2 : list2) {
				for (int y = 0; y < test.length; y++) {
					System.out.printf(test[y] + "\t");
				}
				for (int j = 0; j < l2.length; j++) {
					System.out.printf(l2[j] + "\t");//
				}
				System.out.println();
			}

		}

	}
}
