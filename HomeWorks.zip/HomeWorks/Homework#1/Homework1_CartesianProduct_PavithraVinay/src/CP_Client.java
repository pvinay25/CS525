import java.util.ArrayList;
import java.util.HashMap;

public class CP_Client {
	public static void main(String args[]) {
		/*
		 * uncomment commented code to check the amount of time the program
		 * takes to generate Cartesian product
		 */
		// long startTime = System.currentTimeMillis();

		HashMap<String, String> map1 = new HashMap<String, String>();
		HashMap<String, String> map2 = new HashMap<String, String>();
		ArrayList<String[]> list1 = new ArrayList<String[]>();
		ArrayList<String[]> list2 = new ArrayList<String[]>();
		CartesianProduct cp = new CartesianProduct();

		map1 = cp.readDataFromFile("test1.txt");
		list1 = cp.getIndividualItems(map1);

		map2 = cp.readDataFromFile("test2.txt");
		list2 = cp.getIndividualItems(map2);

		cp.showCartesianProduct(list1, list2, new String[list1.get(0).length]);
		// long stopTime = System.currentTimeMillis();
		// long elapsedTime = stopTime - startTime;
		// System.out.println(elapsedTime);
	}

}
