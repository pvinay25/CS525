Binary Tree Comparison:

Author: Pavithra Vinay
CWID: A20369869

About this program:
It has two classes, Node and BinaryTree. Class Node has instance variables and getters and setters for the instance variables.
Class Binary Tree has the main method and a method to compare 2 binary tress. 
compareTress method takes 2 objects of type Node and returns true or false based on the structure and elements of trees.

To run this program:
Open source code in an IDE of your choice.
Go to Binary Tree class and create two binary trees (I have created 2 sample trees)
and execute the program to see if they are equal.

