class BinaryTree {

	private Node root1;
	private Node root2;

	public BinaryTree() {

	}

	public boolean compareTrees(Node a, Node b) {

		if (a == null && b == null)
			return true;

		if (a != null && b != null) {
			return (a.getData() == b.getData() && compareTrees(a.getLeftNode(), b.getLeftNode())
					&& compareTrees(a.getRightNode(), b.getRightNode()));
		} else

			return false;
	}

	public static void main(String[] args) {

		BinaryTree tree = new BinaryTree();

		tree.root1 = new Node(1);
		tree.root1.setLeftNode(new Node(2));
		tree.root1.setRightNode(new Node(3));
		tree.root1.getLeftNode().setLeftNode(new Node(4));
		tree.root1.getLeftNode().setRightNode(new Node(5));
		// tree.root1.getRightNode().setRightNode(new Node(8));

		tree.root2 = new Node(1);
		tree.root2.setLeftNode(new Node(2));
		tree.root2.setRightNode(new Node(3));
		tree.root2.getLeftNode().setLeftNode(new Node(4));
		tree.root2.getLeftNode().setRightNode(new Node(5));
		// tree.root2.getRightNode().setLeftNode(new Node(8));

		if (tree.compareTrees(tree.root1, tree.root2))
			System.out.println("Both trees are identical.");
		else
			System.out.println("Trees are not identical.");

	}
}